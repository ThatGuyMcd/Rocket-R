Rocket-R Platform Repair v18
==============================

This cumulative repair keeps the v17 Android fixes and changes the Linux/Steam Deck release so Steam Deck no longer depends on AppImage/FUSE at launch time.

Android:
- Keeps the permanent Android source guards from v15-v17.
- Build-Android does not rewrite src/main.cpp or src/rt64_renderer.cpp on every build.
- Keeps the corrected :app:assembleRelease Gradle dispatch from v17.

Linux / Steam Deck:
- Normal Linux AppImages still use zstd SquashFS and the pinned Type-2 runtime.
- Every AppImage is extraction-validated during the build.
- The generic Portable.tar.gz launcher uses --appimage-extract-and-run, avoiding a FUSE mount.
- NEW: x86_64 also emits Linux-x86_64-SteamDeck.tar.gz.
- The Steam Deck archive contains the validated AppDir itself and starts AppRun directly.
  No AppImage mount, FUSE or AppImage integration layer is involved at launch time.
- START-ROCKET-R.sh writes ~/.local/state/rocket-r/steamdeck-launch.log BEFORE Rocket-R starts.
- The launcher clears LD_PRELOAD so Steam overlay injection cannot prevent the native app from starting.
- INSTALL-MENU-SHORTCUT.sh can add a normal KDE application-menu shortcut.
- If Rocket-R exits before opening a window, the Deck launcher shows a KDE error/notification and points to the launch log.
- Low-level X11/XCB/Wayland/DRM/GL libraries are left to SteamOS/Mesa instead of being forced from Ubuntu 22.04 ahead of the host GPU stack.

Install:
1. Extract this whole folder into D:\Rocket-R.
2. Run APPLY-Rocket-R-PLATFORM-REPAIR-v18.cmd.
3. Run ONE-CLICK-BUILD.cmd.

Steam Deck:
Use platform [2] Linux x86_64.
Prefer Rocket-R-<version>-Linux-x86_64-SteamDeck.tar.gz.
Extract the tar.gz ON THE STEAM DECK, then run START-ROCKET-R.sh.
Do not use Linux aarch64 on Steam Deck.

The ordinary .AppImage is still created for standard Linux systems.
FIXED27 gameplay/interpolation remains untouched.
