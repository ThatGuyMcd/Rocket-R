Rocket-R Platform Repair v17
==============================

This cumulative repair covers BOTH Android and Linux packaging and fixes the v16 installer/Gradle wrapper regressions.

Android:
- Keeps the v15 permanent Android source guards.
- Build-Android no longer rewrites src/main.cpp or src/rt64_renderer.cpp on every build.
- Retains the proven Java/SDK/SDL2/zstd/Python/RT64 Android portability fixes.
- Fixes v16 Gradle dispatch: Windows CMD no longer loses :app:assembleRelease and runs `help`.
- Removes the nested-quote path that produced: `" is not recognized as an internal or external command.`

Linux / Steam Deck:
- FIXES the AppImage payload compression. The previous packager used XZ, but the
  modern Type-2 runtime supports zlib/zstd and cannot mount that XZ SquashFS.
- Uses zstd SquashFS.
- Pins AppImage type2-runtime release 20251108 and verifies SHA-256.
- Build-validates every AppImage with --appimage-extract.
- Fixes v16 installer verification: --appimage-extract is verified in package_appimage.sh, not Build-Linux.sh.
- Also emits Portable.tar.gz so Unix execute permissions survive a Windows/NTFS hop.
- Linux x86_64 is the Steam Deck build. Linux aarch64 is ARM64 hardware only.

Install:
1. Extract this whole folder into D:\Rocket-R.
2. Run APPLY-Rocket-R-PLATFORM-REPAIR-v17.cmd.
3. Run ONE-CLICK-BUILD.cmd.

Steam Deck:
Use option [2]. Prefer the generated Linux-x86_64-Portable.tar.gz and extract it
on the Deck. The raw AppImage is also generated, but an ordinary Windows file
copy can lose Linux executable permission metadata.

FIXED27 gameplay/interpolation remains untouched.
