$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Banner([string]$Text) {
    Write-Host ""
    Write-Host ("=" * 76)
    Write-Host ("  " + $Text)
    Write-Host ("=" * 76)
}

function Find-Python {
    $p = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($p) { return $p.Source }
    $p = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($p) { return $p.Source }
    throw "Python 3 was not found."
}

function Find-Ninja {
    $candidates = @(
        "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe",
        "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe",
        "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath $c) { return $c }
    }
    $whereOutput = & where.exe ninja.exe 2>$null
    if ($LASTEXITCODE -eq 0 -and $whereOutput) {
        foreach ($candidate in @($whereOutput)) {
            if (Test-Path -LiteralPath $candidate) { return $candidate }
        }
    }
    $p = Get-Command ninja.exe -ErrorAction SilentlyContinue
    if ($p -and (Test-Path -LiteralPath $p.Source)) { return $p.Source }
    return $null
}

$ScriptPath = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ScriptPath)) {
    throw "Unable to determine installer script path."
}
$Root = (Get-Item -LiteralPath (Split-Path -Parent $ScriptPath) -ErrorAction Stop).FullName
$Python = Find-Python
$Payload = Join-Path $Root "Payload"
$Apply = Join-Path $Payload "scripts\apply_graphics_v16.py"
$Verify = Join-Path $Payload "scripts\verify_graphics_v16.py"
$SelfCheck = Join-Path $Root "scripts\self_check.py"

Banner "Rocket-R Graphics v16 VIEWPORT-LOCKED FOV CULLING FIX"
Write-Host "Repository: $Root"
Write-Host "Repairs the incorrect v15 ABI interpretation and restores FOV/aspect-aware side culling."
Write-Host "Uses Rocket's real Vec3f pointer ABI: r5=position pointer, r6=cullRadius, r7=renderDistance."
Write-Host "Draw Distance, Controls, RT64 patches, interpolation and Graphics UI are not changed."

if (!(Test-Path -LiteralPath $SelfCheck)) {
    throw "Missing scripts\self_check.py"
}

& $Python $SelfCheck
if ($LASTEXITCODE -ne 0) {
    throw "Existing Rocket-R source self-check failed before v16; no changes were made."
}
Write-Host "[OK] Existing Rocket-R source self-check PASS."

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $Root "build\repair-backups\graphics-v16-$stamp"
$tracked = @(
    "src\widescreen_culling.cpp",
    "scripts\self_check.py"
)

foreach ($rel in $tracked) {
    $source = Join-Path $Root $rel
    if (Test-Path -LiteralPath $source) {
        $dest = Join-Path $backup $rel
        $destDir = Split-Path -Parent $dest
        New-Item -ItemType Directory -Force -Path $destDir | Out-Null
        Copy-Item -LiteralPath $source -Destination $dest -Force
    }
}
Write-Host "[OK] Backup: $backup"

try {
    & $Python $Apply --root $Root
    if ($LASTEXITCODE -ne 0) { throw "v16 source repair failed." }

    & $Python $Verify --root $Root
    if ($LASTEXITCODE -ne 0) { throw "v16 ABI/FOV verification failed." }

    & $Python $SelfCheck
    if ($LASTEXITCODE -ne 0) { throw "Rocket-R source self-check failed after v16." }

    Write-Host "[OK] v16 structural verification and source self-check PASS."
}
catch {
    Write-Host "[ERROR] v16 failed before compiler validation; restoring the automatic backup."
    foreach ($rel in $tracked) {
        $saved = Join-Path $backup $rel
        if (Test-Path -LiteralPath $saved) {
            Copy-Item -LiteralPath $saved -Destination (Join-Path $Root $rel) -Force
        }
    }
    throw
}

$BuildDir = Join-Path $Root "build\windows"
$BuildNinja = Join-Path $BuildDir "build.ninja"
$Ninja = Find-Ninja

if ((Test-Path -LiteralPath $BuildNinja) -and $Ninja) {
    $logDir = Join-Path $Root "build\logs"
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    $smokeLog = Join-Path $logDir "graphics-v16-compile-smoke-$stamp.log"

    Banner "Incremental Windows compile smoke-test"
    Write-Host "Ninja: $Ninja"
    Write-Host "Build directory: $BuildDir"
    Write-Host "Log: $smokeLog"

    & $Ninja -C $BuildDir RocketR -j 1 2>&1 | Tee-Object -FilePath $smokeLog
    $compileRc = $LASTEXITCODE
    if ($compileRc -ne 0) {
        Write-Host ""
        Write-Host "[ERROR] v16 source verification passed, but Ninja exposed a compiler/linker error."
        Write-Host "[ERROR] The v16 source is intentionally LEFT IN PLACE."
        Write-Host "[ERROR] Send this log: $smokeLog"
        exit $compileRc
    }
    Write-Host "[OK] Incremental Windows RocketR target compiled and linked successfully."
}
else {
    Write-Host "[INFO] Existing Windows Ninja build was not available; compiler smoke-test skipped."
    Write-Host "[INFO] Run ONE-CLICK-BUILD.cmd for the full build."
}

Banner "v16 COMPLETE"
Write-Host "Correct pointer ABI and viewport-locked horizontal/vertical FOV culling are installed."
exit 0
