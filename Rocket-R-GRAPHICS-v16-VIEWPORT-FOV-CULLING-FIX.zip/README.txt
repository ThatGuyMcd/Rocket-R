Rocket-R Graphics v16 - VIEWPORT-LOCKED FOV CULLING FIX
========================================================

This supersedes Graphics v15 and is specifically based on the 23:04:22 test
video supplied after v15.

What the video proves
---------------------
Objects disappear and reappear while staying at roughly the same camera depth,
and some are culled well inside the visible 16:9 viewport while the camera
turns. That rules out Draw Distance as the primary fault and points directly at
the CPU side-plane/FOV guard.

What actually broke in v15
--------------------------
The v15 ABI interpretation was wrong.

Rocket defines:

  typedef float Vec3f[3];

frustum_test is declared with a parameter `Vec3f position`. In a C function
parameter an array type decays to a pointer. The real o32 argument layout is:

  r4       camera pointer
  r5       position pointer
  r6       cullRadius float bits
  r7       renderDistance float bits
  sp+0x10  arg4 pointer
  sp+0x14  alphaOut pointer

v15 incorrectly read r5/r6/r7 as inline X/Y/Z values and then treated stack
arguments as cullRadius/renderDistance. Once that bad hook actually ran, the
FOV target test was operating on invalid object coordinates and radius data.
That is why horizontal/vertical culling stopped following the viewport.

What v16 changes
----------------
- Restores the correct Rocket Vec3f pointer ABI:
    r5 = position pointer
    r6 = cullRadius
    r7 = renderDistance
- Leaves renderDistance completely untouched in the widescreen hook.
- Reads the actual object position from the r5 guest pointer.
- Uses Rocket's live camera-forward vector, so the target frustum rotates with
  yaw/pitch/roll.
- Uses effective vertical FOV directly for top/bottom coverage.
- Recomputes horizontal coverage from that effective vertical FOV multiplied by
  the selected aspect ratio.
- Uses an exact rectangular four-side-plane sphere test rather than a diagonal
  cone.
- Adds a 20% tangent-space safety area beyond all viewport edges so objects are
  retained before they enter the visible image.
- Does NOT rewrite Rocket's shared camera planes.
- Relaxes only the current object's r6 cullRadius when its sphere intersects the
  expanded target viewport.

Install
-------
Extract this ZIP directly into D:\Rocket-R, then run:

  APPLY-Rocket-R-GRAPHICS-v16-VIEWPORT-FOV-CULLING-FIX.cmd

The installer runs the existing source self-check before changing anything,
creates an automatic backup, patches the source, runs v16 structural checks,
runs the source self-check again, and uses the existing Windows Ninja build for
an incremental compile/link smoke-test when available.

Expected runtime diagnostic
---------------------------
The first active expanded-frustum call should print:

  [culling] v16 viewport-locked FOV/aspect guard active;

The diagnostic also reports authored -> target aspect and vertical FOV. Those
numbers are useful evidence if any edge case remains.
