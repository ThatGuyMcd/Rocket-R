@echo off
setlocal
cd /d "%~dp0"
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-Rocket-R-GRAPHICS-v16-VIEWPORT-FOV-CULLING-FIX.ps1"
set "rc=%ERRORLEVEL%"
echo.
if not "%rc%"=="0" (
  echo v16 culling fix reported exit code %rc%.
) else (
  echo Graphics v16 viewport/FOV culling fix completed successfully.
)
pause
exit /b %rc%
