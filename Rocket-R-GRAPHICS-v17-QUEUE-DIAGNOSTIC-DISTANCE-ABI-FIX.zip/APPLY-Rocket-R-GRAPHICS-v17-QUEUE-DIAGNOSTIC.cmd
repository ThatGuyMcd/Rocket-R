@echo off
setlocal
cd /d "%~dp0"
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-Rocket-R-GRAPHICS-v17-QUEUE-DIAGNOSTIC.ps1"
set "rc=%ERRORLEVEL%"
echo.
if not "%rc%"=="0" (
  echo v17 diagnostic repair reported exit code %rc%.
) else (
  echo Graphics v17 queue diagnostic + distance ABI repair completed successfully.
)
pause
exit /b %rc%
