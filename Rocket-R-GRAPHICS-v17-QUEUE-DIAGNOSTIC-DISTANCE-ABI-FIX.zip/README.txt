Rocket-R Graphics v17 - RENDER-QUEUE DIAGNOSTIC + DISTANCE ABI REPAIR
=====================================================================

Why v16 is much better but can still pop in dense levels / directions
---------------------------------------------------------------------
The remaining symptom is different from the earlier broken frustum:

- v16 now tracks the expanded viewport/FOV much more accurately.
- Yet some scenery, and sometimes Rocket/parts of Rocket, can disappear only
  when the camera points into particular dense parts of certain levels.

Rocket's original renderer has a separate hard limit:

  add_render_entry() accepts entries only while the render list contains < 256.

The backing guest array is physically exactly 256 RenderEntry records. Once it
is full, later entries are silently rejected. Widescreen/FOV expansion allows
more geometry to survive the original 4:3 culling budget, so a dense camera
angle can plausibly overflow the list. Changing camera direction changes which
objects are submitted and their order, which can make different elements pop.
This also explains why Graphics v14 was dramatically worse: it allowed far too
much through the CPU side cull and therefore put much more pressure on the same
fixed render list.

IMPORTANT: v17 does NOT simply change 256 to 512. That would corrupt adjacent
N64 guest globals because the original backing array is only 0x1800 bytes:
256 entries x 24 bytes.

A second confirmed regression
-----------------------------
The separate Draw Distance hook had regressed to the old v9 ABI mistake. The
real frustum_test layout is:

  r4       camera pointer
  r5       position pointer
  r6       cullRadius
  r7       renderDistance
  sp+0x10  arg4 pointer
  sp+0x14  alphaOut pointer

v16's widescreen hook uses the correct layout, but graphics_enhancements.cpp
was still reading sp+0x14 as renderDistance. v17 restores renderDistance to r7.

What v17 changes
----------------
- Keeps the v16 viewport/FOV culling algorithm unchanged.
- Repairs Draw Distance / Maximum Detail to modify r7, the real renderDistance.
- Adds a non-invasive render-list pressure diagnostic using the existing
  add_render_entry presentation hook.
- Logs once if a frame reaches 240+ visible render-entry attempts.
- Logs once if a frame attempts more than 256 visible entries, including the
  minimum number the original renderer silently dropped.
- Does NOT enlarge, relocate, or overwrite the fixed guest render array.

Install
-------
Extract this ZIP directly into D:\Rocket-R and run:

  APPLY-Rocket-R-GRAPHICS-v17-QUEUE-DIAGNOSTIC.cmd

Then build/run normally and reproduce one of the camera directions where the
popping occurs.

Evidence to look for
--------------------
If the remaining popping is render-list saturation, stderr/runtime output will
contain something like:

  [render-queue] PRESSURE: previous authored frame attempted 248/256 ...

or, more importantly:

  [render-queue] SATURATION: previous authored frame attempted 287 visible
  entries, but Rocket's guest render list physically holds only 256. At least
  31 entries were silently rejected ...

That would prove the remaining issue is no longer the viewport frustum. The
proper follow-up is overflow-aware render-list handling, not another culling
widening hack.
