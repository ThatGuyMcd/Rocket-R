$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Banner([string]$Text) {
    Write-Host ""
    Write-Host ("=" * 76)
    Write-Host ("  " + $Text)
    Write-Host ("=" * 76)
}

function Find-Python {
    $p = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($p) { return $p.Source }
    $p = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($p) { return $p.Source }
    throw "Python 3 was not found."
}

function Find-Ninja {
    $candidates = @(
        "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe",
        "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe",
        "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe"
    )
    foreach ($c in $candidates) { if (Test-Path -LiteralPath $c) { return $c } }
    $whereOutput = & where.exe ninja.exe 2>$null
    if ($LASTEXITCODE -eq 0 -and $whereOutput) {
        foreach ($candidate in @($whereOutput)) {
            if (Test-Path -LiteralPath $candidate) { return $candidate }
        }
    }
    return $null
}

$ScriptPath = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ScriptPath)) { throw "Unable to determine installer script path." }
$Root = (Get-Item -LiteralPath (Split-Path -Parent $ScriptPath) -ErrorAction Stop).FullName
$Python = Find-Python
$Apply = Join-Path $Root "Payload\scripts\apply_graphics_v17.py"
$Verify = Join-Path $Root "Payload\scripts\verify_graphics_v17.py"
$SelfCheck = Join-Path $Root "scripts\self_check.py"

Banner "Rocket-R Graphics v17 RENDER-QUEUE DIAGNOSTIC + DISTANCE ABI REPAIR"
Write-Host "Repository: $Root"
Write-Host "Keeps v16 viewport/FOV culling, repairs renderDistance=r7, and detects 256-entry render-list saturation."

if (!(Test-Path -LiteralPath $SelfCheck)) { throw "Missing scripts\self_check.py" }
& $Python $SelfCheck
if ($LASTEXITCODE -ne 0) { throw "Existing Rocket-R source self-check failed before v17; no changes were made." }
Write-Host "[OK] Existing Rocket-R source self-check PASS."

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $Root "build\repair-backups\graphics-v17-$stamp"
$tracked = @(
    "src\graphics_enhancements.cpp",
    "src\presentation_identity.cpp"
)
foreach ($rel in $tracked) {
    $source = Join-Path $Root $rel
    if (Test-Path -LiteralPath $source) {
        $dest = Join-Path $backup $rel
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
        Copy-Item -LiteralPath $source -Destination $dest -Force
    }
}
Write-Host "[OK] Backup: $backup"

try {
    & $Python $Apply --root $Root
    if ($LASTEXITCODE -ne 0) { throw "v17 source repair failed." }
    & $Python $Verify --root $Root
    if ($LASTEXITCODE -ne 0) { throw "v17 structural verification failed." }
    & $Python $SelfCheck
    if ($LASTEXITCODE -ne 0) { throw "Rocket-R source self-check failed after v17." }
    Write-Host "[OK] v17 structural verification and source self-check PASS."
}
catch {
    Write-Host "[ERROR] v17 failed before compiler validation; restoring automatic backup."
    foreach ($rel in $tracked) {
        $saved = Join-Path $backup $rel
        if (Test-Path -LiteralPath $saved) {
            Copy-Item -LiteralPath $saved -Destination (Join-Path $Root $rel) -Force
        }
    }
    throw
}

$BuildDir = Join-Path $Root "build\windows"
$BuildNinja = Join-Path $BuildDir "build.ninja"
$Ninja = Find-Ninja
if ((Test-Path -LiteralPath $BuildNinja) -and $Ninja) {
    $logDir = Join-Path $Root "build\logs"
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    $smokeLog = Join-Path $logDir "graphics-v17-compile-smoke-$stamp.log"
    Banner "Incremental Windows compile smoke-test"
    & $Ninja -C $BuildDir RocketR -j 1 2>&1 | Tee-Object -FilePath $smokeLog
    $compileRc = $LASTEXITCODE
    if ($compileRc -ne 0) {
        Write-Host "[ERROR] Source verification passed, but Ninja exposed a compiler/linker error."
        Write-Host "[ERROR] v17 source is LEFT IN PLACE. Send this log: $smokeLog"
        exit $compileRc
    }
    Write-Host "[OK] Incremental Windows RocketR target compiled and linked successfully."
} else {
    Write-Host "[INFO] Existing Windows Ninja build unavailable; compile smoke-test skipped."
    Write-Host "[INFO] Run ONE-CLICK-BUILD.cmd for the full build."
}

Banner "v17 COMPLETE"
Write-Host "Reproduce a known popping camera angle and watch for [render-queue] diagnostics."
exit 0
